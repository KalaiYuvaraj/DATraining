SELECT 
    Customers.CustomerName,
    SUM(Orders.Total) AS TotalSales
FROM 
    Orders 
INNER JOIN 
    Customers  ON Customers.CustomerID = Orders.CustomerID
GROUP BY 
    Customers.CustomerName, Customers.CustomerID

