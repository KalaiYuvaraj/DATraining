SELECT TOP 1
    Products.ProductName,
    SUM(Orders.Quantity) AS TotalQuantity
FROM 
    Orders 
INNER JOIN 
    Products  ON Orders.ProductID = Products.ProductID
GROUP BY 
    Products.ProductName
ORDER BY 
    TotalQuantity DESC;
