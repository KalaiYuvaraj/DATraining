SELECT 
    Products.ProductName,
    SUM(Orders.Total) AS TotalRevenue
FROM 
    Orders 
INNER JOIN 
    Products  ON Products.ProductID = Orders.ProductID
GROUP BY 
    Products.ProductName

