SELECT TOP 3
    Customers.CustomerName,
    SUM(Orders.Total) AS TotalSales
FROM 
    Orders 
INNER JOIN 
    Customers  ON Orders.CustomerID = Customers.CustomerID
GROUP BY 
    Customers.CustomerName
ORDER BY 
    TotalSales DESC;
