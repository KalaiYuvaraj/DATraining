SELECT * FROM Products
SELECT * FROM Customers
SELECT * FROM Orders
